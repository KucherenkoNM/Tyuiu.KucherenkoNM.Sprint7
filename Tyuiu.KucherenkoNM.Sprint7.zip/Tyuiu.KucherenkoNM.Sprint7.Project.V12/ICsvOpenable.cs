namespace Tyuiu.KucherenkoNM.Sprint7.Project.V12
{
    public interface ICsvOpenable
    {
        void OpenFromCsv(string filePath);
    }
}
