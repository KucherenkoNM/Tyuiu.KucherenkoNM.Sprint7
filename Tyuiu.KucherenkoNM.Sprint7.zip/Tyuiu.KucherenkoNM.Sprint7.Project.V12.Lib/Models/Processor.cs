﻿namespace Tyuiu.KucherenkoNM.Sprint7.Project.V12.Lib.Models
{
    public class Processor
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Manufacturer { get; set; } = string.Empty;
        public int Cores { get; set; }
    }
}
